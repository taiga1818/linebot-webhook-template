# LINE Bot Webhook Template

赤が画像に含まれているかを判定するLINE Botです。

## 機能
- LINEで送られた画像を受信
- OpenCVで赤色成分を解析
- 赤が含まれていれば通知